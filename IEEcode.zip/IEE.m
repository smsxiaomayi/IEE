function out = IEE(x, y, p, k, Thei, Ndelta)
%IEE: compute the intervened causality strength from x to y with order p.
% x: dx*T time series with T time points.
% y: dy*T time series with T time points.
% p: the order of model to estimate causality.
% k: the k-th nearest number to use in calculating entropy, at least 2.
% Thei: half the length of Theiler correction window. [-Thei, Thei] around point i. Thei>=p.
%Use the kNN method to estimate the CMI(deltaX, deltaY|Y*), where deltaX = X_NN-X, deltaY = Y_NN-Y*
% average MI(deltaX, deltaY) at each Y*
%kNN formular MI(X, Y) = psi(k) - <psi(nX+1) + psi(nY+1) - psi(nN+1)>.

if (nargin<3 || p<1), p = 1; end
if (nargin<4 || k<2), k = 2; end
if (nargin<5 || Thei<p), Thei = p; end
if (nargin<6), Ndelta = 10; end

[dy, T] = size(y); dx = size(x, 1);

X = zeros(T-p, dx*p); % dx*p columns
for i = 1:p
    X(:, ((i-1)*dx+1):(i*dx)) = x(:, (p+1-i):(end-i))';
end

Y = zeros(T-p, dy*(p+1)); %dy*(p+1) columns
Y(:, 1:dy) = y(:, (p+1):end)';
for i = 1:p
    Y(:, (i*dy+1):((i+1)*dy)) =  y(:, (p+1-i):(end-i))'; %dy*p columns
end

%The Ndelta NN of Y_t on Manifold M_Y, calculate deltaY_t and deltaX_t with same time label.


out = zeros(T-p, 1);
for i = 1:(T-p)
    % Theiler correction. Points around i are excluded.
    ids = max(1, i-Thei); idf = min(i+Thei, T-p); idx = ones(T-p, 1); idx(ids:idf) = 0; idx = logical(idx);
    %dy*(p+1)+1 NN in Y_t space
    tempY1 = Y(idx, :);
    [pnnidx, ~] = knnsearch(tempY1, Y(i, :), 'K', Ndelta, 'Distance', 'euclidean'); %Ndelta th NN
    tempY2 = tempY1(pnnidx, :);
    YpNN = tempY2-Y(i, :);

    %dy*(p+1)+1 NN in X_t space
    tempX1 = X(idx, :);
    tempX2 = tempX1(pnnidx, :);
    XpNN = tempX2-X(i, :);
    out(i) = MIknn(XpNN, YpNN, k);
end
out = mean(out);
end

function out = MIknn(XpNN, YpNN, k)

[~, id0] = unique([XpNN, YpNN], 'rows', 'stable');
XpNN = XpNN(id0,:); YpNN = YpNN(id0,:); Np = size(XpNN, 1);

%Calculate mutual information of prediction
% kNN in (XpNN, YpNN) space
nXpNN = zeros(Np, 1); nYpNN = zeros(Np, 1);
for i = 1:Np
    %kNN in (XpNN, YpNN) space, 1st is point i itself, use k+1
    [~, D] = knnsearch([XpNN, YpNN], [XpNN(i, :), YpNN(i, :)], 'K', k+1, 'Distance', 'chebychev');
    halfepsilonXYkNN = D(k+1); %the distance of kNN = epsilon/2
    nXpNN(i) = sum(pdist2(XpNN, XpNN(i, :), 'chebychev')<halfepsilonXYkNN); %include i itself
    nYpNN(i) = sum(pdist2(YpNN, YpNN(i, :), 'chebychev')<halfepsilonXYkNN); %include i itself
end

%tauDC index
idN = (nXpNN~=0)&(nYpNN~=0);
out = abs(psi(k) - mean(psi(nXpNN(idN))) - mean(psi(nYpNN(idN))) + psi(Np));
end
